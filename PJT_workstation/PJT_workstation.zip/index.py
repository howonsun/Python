#!C:\Users\user\AppData\Local\Programs\Python\Python310\python.exe
print("content-type: text/html; charset=euc-kr\n")
import cgi

print('''
<!DOCTYPE html>
<html>
<head>
    <title>Howon's work Station</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/index_platform.css">
</head>
<body>
    <div class="grid">
        <div class="callender">
            <div class="cal_top">
                callender_top
            </div>
            <div class="cal_main">
                callender_main
            </div>
            <div class="cal_bottom">
                <div class="cal_pm">
                    previous month
                </div>
                <div class="cal_tm">
                    This Month
                </div>
                <div class="cal_nm">
                    next month
                </div>
            </div>
        </div>
        <div class="information">
            <div class="task_check">
                <div class="task_info">
                    Task information
                </div>
                <div class="task_history">
                    Task history
                </div>
            </div>
            <div class="task_buttons">
                Buttons
            </div>
            <div class="task_for_days">
                <div class="task_daily">
                    Daily check
                </div>
                <div class="task_simple">
                    Simple task
                </div>
            </div>  
        </div>
        <div class="documents">
            <div class="docs_official">
                Official docs
            </div>
            <div class="docs_material">
                Material docs
            </div>
            <div class="docs_new">
                New docs
            </div>
        </div>
    </div>
</body>
</html>
''')